#!/bin/sh
umask 0011
$1
