#!/bin/sh

# Go parameters
BIN_FOLDER=bin
SH=$BIN_FOLDER/run.sh
BAT=$BIN_FOLDER/run.bat
BIN_NAME=main
GO_CMD=go
GO_BUILD="$GO_CMD build"
GO_TEST=$GO_CMD test
CMD_PATH=main.go
BIN_FOLDER_DARWIN=../$BIN_FOLDER/darwin
BIN_DARWIN=$BIN_FOLDER_DARWIN/$BIN_NAME
BIN_FOLDER_LINUX=../$BIN_FOLDER/linux
BIN_LINUX=$BIN_FOLDER_LINUX/$BIN_NAME
BIN_FOLDER_WINDOWS=../$BIN_FOLDER/windows
BIN_WINDOWS=$BIN_FOLDER_WINDOWS/$BIN_NAME.exe

build_formula() {
  go_build
  sh_unix
  bat_windows
  docker_gen
}

go_build() {
  cd src || exit
  mkdir -p $BIN_FOLDER_DARWIN $BIN_FOLDER_LINUX $BIN_FOLDER_WINDOWS
  #LINUX
  CGO_ENABLED=0 GOOS=linux GOARCH=amd64 $GO_BUILD -o $BIN_LINUX $CMD_PATH
  #MAC
  GOOS=darwin GOARCH=amd64 $GO_BUILD -o $BIN_DARWIN $CMD_PATH
  #WINDOWS 64
  GOOS=windows GOARCH=amd64 $GO_BUILD -o $BIN_WINDOWS $CMD_PATH
  cd ..
}

sh_unix() {
  echo '#!/bin/sh' >$SH
  echo 'if [ "$(uname)" = "Darwin" ]; then' >>$SH
  echo '$(dirname "$0")'/darwin/$BIN_NAME >>$SH
  echo 'else' >>$SH
  echo '$(dirname "$0")'/linux/$BIN_NAME >>$SH
  echo 'fi' >>$SH
  chmod +x $SH
}

bat_windows() {
  echo '@ECHO OFF' >$BAT
  echo 'start /B /WAIT windows/main.exe' >>$BAT
}

docker_gen() {
  cp Dockerfile set_umask.sh $BIN_FOLDER
}

test() {
  $GOTEST -short "$(go list ./... | grep -v vendor/)"
}

build_formula
